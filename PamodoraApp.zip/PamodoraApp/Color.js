class color{
    static GreenBg = '#F2FFF5';
    static GreenText = '#14401D';
    static GreenBtnColor = '#4DDA6E62';
    static GreenSbtnColor = '#4DDA6E15';

    static BlueBg = '#F2F9FF';
    static BlueText = '#153047';
    static BlueBtnColor = '#4CACFF62';
    static BlueSbtnColor = '#4CACFF15';

    static bgColor = '#FFD9D9';
    static FocusText = '#471515';
    static FocusBtnColor = '#FF4C4C70';
    static FocusSbtnColor = '#FF4C4C15';

}




export default color;