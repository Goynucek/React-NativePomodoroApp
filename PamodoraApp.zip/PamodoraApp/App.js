import { StatusBar } from 'expo-status-bar';
import { Button, StyleSheet, Text, View, Alert, Image, TouchableOpacity, Vibration,Modal,TextInput } from 'react-native';
import React, { useState, useEffect } from 'react';

import color from './Color.js';
let Round = 0;

export default function App() {
  const [minute, setMinute] = useState(20);
  const [seconds, setSeconds] = useState(0);
  const [timerActive, setTimerActive] = useState(false);

  const [bgColor, setBgColor] = useState('#FFD9D9');
  const [TextColor, setTextColor] = useState('#FFFFFF');
  const [btnColor, setBtnColor] = useState('#FF4C4C70');
  const [sBtncolor, setSbtnColor] = useState('#FF4C4C15');
  const [HeaderIconn, setHeaderIcon] = useState(require('./Images/brain.png'));

  const [settings, setSettings] = useState(false);

  const [focusTime, setFocus] = useState(25);
  const [BreakTime, setBreakTime] = useState(5);
  const [LBreakTime, setLBreakTime] = useState(15);



  styles.container.backgroundColor = bgColor;
  styles.Header.backgroundColor = bgColor;
  styles.HeaderText.color = TextColor;
  styles.TopText.color = TextColor;
  styles.BottomText.color = TextColor;
  styles.ToggleButton.backgroundColor = btnColor;
  styles.SideButton.backgroundColor = sBtncolor;




  function green()
  {
    Vibration.vibrate();
    setBgColor(color.GreenBg); // Süre bittiğinde arkaplan rengi
    setTextColor(color.GreenText); // Süre bittiğinde metin rengi
    setBtnColor(color.GreenBtnColor); // Süre bittiğinde buton rengi
    setSbtnColor(color.GreenSbtnColor); // Süre bittiğinde yan buton rengi
    setMinute(BreakTime);
    setSeconds(0);
    setTimerActive(true);
    setHeaderIcon(require('./Images/coffee-cup.png'));
  }

  function Focus()
  {
    Vibration.vibrate();
    Round++;
    console.log(Round);
    setBgColor(color.bgColor); // Süre bittiğinde arkaplan rengi
    setTextColor(color.TextColor); // Süre bittiğinde metin rengi
    setBtnColor(color.FocusBtnColor); // Süre bittiğinde buton rengi
    setSbtnColor(color.FocusSbtnColor);
    setMinute(focusTime);
    setSeconds(0);
    setTimerActive(true);
    setHeaderIcon(require('./Images/brain.png'));
  }

  function LongBreak()
  {
    Round = 0;
    setBgColor(color.BlueBg); // Süre bittiğinde arkaplan rengi
    setTextColor(color.BlueText); // Süre bittiğinde metin rengi
    setBtnColor(color.BlueBtnColor); // Süre bittiğinde buton rengi
    setSbtnColor(color.BlueSbtnColor); // Süre bittiğinde yan buton rengi
    setMinute(LBreakTime);
    setSeconds(0);
    setTimerActive(true);
    setHeaderIcon(require('./Images/brain.png'));
  }

  function SetTime()
  {
    setTimerActive(false);
    setSettings(false);
    Focus();
  }

  useEffect(() => {
    let interval;

    if (timerActive) {
      interval = setInterval(() => {
        if (seconds > 0) {
          setSeconds((prevSeconds) => prevSeconds - 1);
        } else {
          if (minute > 0) {
            setSeconds(59);
            setMinute((prevMinute) => prevMinute - 1);
          } else {
            // Süre dolduğunda yapılacak işlemler
            setTimerActive(false);
          }
        }
      }, 1000);
    }


    if (minute === 0 && seconds === 0) {
      if(Round == 4)
      {
        LongBreak();
      }
      else if(bgColor == '#FFF2F2')
      {
      // BreakTime
        green();
      }else{
        Focus();
      }
    }

    return () => {
      clearInterval(interval);
    };
  }, [timerActive, minute, seconds]);

  const handleToggleTimer = () => {
    if (timerActive) {
      setTimerActive(false);
    } else {
      setTimerActive(true);
    }
  };

  const formatTime = (value) => {
    if (value < 10) {
      return `0${value}`;
    }
    return value;
  };


  return (
    <View style={[styles.container, {backgroundColor: bgColor}]}>
      <View style={styles.Top}>
        <View style={styles.Header}>
          <Image style={styles.HeaderIcon} source={HeaderIconn}></Image>
          <Text style={styles.HeaderText}>{bgColor=='#FFF2F2' ? 'Focus' : 'BreakTime'}</Text>
        </View>
      </View>

      <View style={styles.Middle}>
        <Text style={styles.TopText}>{formatTime(minute)}</Text>
        <Text style={styles.BottomText}>{formatTime(seconds)}</Text>
      </View>

      <View style={styles.Bottom}>
        <View style={styles.Buttons}>
          <TouchableOpacity style={styles.SideButton}  onPress={()=>{setSettings(true)}} ><Image  style={styles.ButtonImage}source={require('./Images/layer.png')}></Image></TouchableOpacity>
          <TouchableOpacity style={styles.ToggleButton} onPress={handleToggleTimer}><Text>{timerActive ? 'Dur' : 'Başlat'}</Text></TouchableOpacity>
          <TouchableOpacity style={styles.SideButton} onPress={()=>{
                  if(Round == 4)
                  {
                    //longBreakTime
                    LongBreak();
                  }
                  else if(bgColor == color.bgColor)
                  {
                  // BreakTime
                  green();
                  }
                  else{
                    //Focus
                    Focus();
                  }

          }}><Image  style={styles.ButtonImage}source={require('./Images/forward-button.png')}></Image></TouchableOpacity>
        </View>
      </View>

      <Modal visible={settings} animationType='fade' transparent={true} style={{justifyContent:'center',alignItems:'center'}}>
          <View style={{flex:1,backgroundColor:'transparent',justifyContent:'center',alignContent:'center'}}>
              <View style={styles.inputUpper}>
                  <Text style={{fontSize:10, top:20}}>Set Time</Text>
                        <View style={styles.inputs}>
                            <TextInput
                              style={styles.input}
                              placeholder="Work"
                              onChangeText={(Text)=>{let time = parseInt(Text); setFocus(time);}}
                              keyboardType="numeric"
                            />
                              <TextInput
                              style={styles.input}
                              onChangeText={(Text)=>{let time = parseInt(Text); setBreakTime(time);}}
                              placeholder="Break"
                              keyboardType="numeric"
                            />

                              <TextInput
                              style={styles.input}
                              onChangeText={(Text)=>{let time = parseInt(Text); setLBreakTime(time);}}
                              placeholder="Long Break"
                              keyboardType="numeric"
                            />     

                        </View>
                        <View style={{top:50}}>
                        <Button title='Apply' onPress={SetTime} />
                        </View>

              </View>
          </View>
      </Modal>


      <StatusBar style="auto" />
    </View>
  );
}






const styles = StyleSheet.create({
  inputUpper:{
    width:235,height:290,backgroundColor:'white',borderRadius:25,left:91,alignItems:'center',
    shadowColor: "#000",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.29,
    shadowRadius: 4.65,
    
    elevation: 7,
  }
  ,
  inputs:{
    borderTopWidth:1.5,
    width:200,
    height:150,
    flexDirection:'column',
    justifyContent:'space-evenly',
    alignItems:'center',
    top:25,

  },
  input:{
    top:20,
    height:25,
    width:200,
    borderWidth : 1,
    borderRadius:50,
    padding:5,
    borderColor: 'grey',
    marginBottom:35,
    marginTop:10,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF2F2'
  },
  Top:{
    flex:1,
    justifyContent: 'flex-end'
  },
  Header:{
    width: 200,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 2,
    borderRadius: 50,
    borderBottomColor: '#471515',
  },
  HeaderIcon:{
    width:25,
    height: 25,
  },
  HeaderText:{
    fontSize: 25,
    alignSelf: 'center',
    marginLeft: 5,
  },
  Middle:{
    flex:2,
    width: 300,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center'
    
  },
  TopText:{
    fontSize:200,
    fontWeight: 'bold',
    letterSpacing: -15,
  },
  BottomText:{
    fontSize:200,
    fontWeight: 'bold',
    letterSpacing: -15,
    bottom: 75,
  },
  Bottom:{
    flex:1
  },
  Buttons:{
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    width : 250,
    bottom: 50
  },
  SideButton:{
    width: 60,
    height:60,
    backgroundColor: '#FF4C4C15',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems:'center'
  },
  ToggleButton:{
    width: 100,
    height:80,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems:'center',
    bottom: 10,
    backgroundColor: '#FF4C4C70'
  },
  ButtonImage:{
    width:25,
    height:25,
    tintColor: '#471515'
  }
});
